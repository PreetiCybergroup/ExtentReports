package TestNgFramework.ExtentReports;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReportsDemo {
	
	ExtentReports report;
	@BeforeTest
	public void config()
	{
		String path = System.getProperty("user.dir")+"//Reporter//index.html";
		ExtentSparkReporter esp = new ExtentSparkReporter(path);
		esp.config().setDocumentTitle("Extent Test Report");
		esp.config().setReportName("Web Automation Testing");

        report = new ExtentReports();
        report.attachReporter(esp);
	}
	
	@Test
	public void initialDemo()
	{
		ExtentTest test = report.createTest("Initial Demo");
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver(); 
		driver.get("https://rahulshettyacademy.com");
		System.out.println(driver.getTitle());
		test.fail("Result do not match");
		driver.close();
		
		report.flush();
		
	}

}
